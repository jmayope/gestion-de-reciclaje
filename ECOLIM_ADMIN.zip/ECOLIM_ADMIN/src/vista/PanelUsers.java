package vista;

import dao.UserDAO;
import modelo.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelUsers extends JPanel {

    private JTable tabla;
    private DefaultTableModel modelo;

    private final UserDAO userDAO = new UserDAO();

    public PanelUsers() {

        initComponents();
        cargarUsuarios();
    }

    private void initComponents() {

        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));

        JLabel titulo = new JLabel("Gestión de User para Empresas", SwingConstants.CENTER);

        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setBorder(
                BorderFactory.createEmptyBorder(20, 0, 20, 0)
        );

        add(titulo, BorderLayout.NORTH);

        modelo = new DefaultTableModel(
                new Object[]{
                        "ID",
                        "Código",
                        "Usuario",
                        "Rol",
                        "Estado"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabla = new JTable(modelo);
        
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 14)
        );

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();

        JButton btnAgregar = new JButton("Agregar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");

        btnAgregar.addActionListener(e -> agregarUsuario());
        btnModificar.addActionListener(e -> modificarUsuario());
        btnEliminar.addActionListener(e -> eliminarUsuario());

        panelBotones.add(btnAgregar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);

        add(panelBotones, BorderLayout.SOUTH);
    }

    private void cargarUsuarios() {

        modelo.setRowCount(0);

        List<User> lista = userDAO.listUsers();

        for (User u : lista) {

            modelo.addRow(new Object[]{
                    u.getId(),
                    u.getCode(),
                    u.getUsername(),
                    u.isPrincipal() ? "Principal" : "Secundario",
                    u.isStatus() ? "Activo" : "Inactivo"
            });
        }
    }

    private void agregarUsuario() {

        JTextField txtEntityId = new JTextField();
        JTextField txtPersonId = new JTextField();
        JTextField txtCode = new JTextField();
        JTextField txtUsername = new JTextField();
        JTextField txtPassword = new JTextField();

        JComboBox<String> cbRol =
                new JComboBox<>(new String[]{"Principal", "Secundario"});

        JCheckBox chkEstado = new JCheckBox("Activo");

        Object[] campos = {
                "Entity ID:", txtEntityId,
                "Person ID:", txtPersonId,
                "Código:", txtCode,
                "Usuario:", txtUsername,
                "Contraseña:", txtPassword,
                "Rol:", cbRol,
                "Estado:", chkEstado
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Agregar Usuario",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            User u = new User();

            u.setEntityId(Long.valueOf(txtEntityId.getText()));
            u.setPersonId(Long.valueOf(txtPersonId.getText()));
            u.setCode(txtCode.getText());
            u.setUsername(txtUsername.getText());
            u.setPassword(txtPassword.getText());

            u.setPrincipal(
                    cbRol.getSelectedItem().toString().equals("Principal")
            );

            u.setStatus(chkEstado.isSelected());

            if (userDAO.insertUser(u)) {

                JOptionPane.showMessageDialog(this,
                        "Usuario agregado correctamente.");

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(this,
                        "No se pudo agregar.");
            }
        }
    }

    private void modificarUsuario() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(this,
                    "Seleccione un usuario.");

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        User u = userDAO.findById(id);

        if (u == null) {
            return;
        }

        JTextField txtEntityId =
                new JTextField(String.valueOf(u.getEntityId()));

        JTextField txtPersonId =
                new JTextField(String.valueOf(u.getPersonId()));

        JTextField txtCode =
                new JTextField(u.getCode());

        JTextField txtUsername =
                new JTextField(u.getUsername());

        JTextField txtPassword =
                new JTextField(u.getPassword());

        JComboBox<String> cbRol =
                new JComboBox<>(new String[]{"Principal", "Secundario"});

        cbRol.setSelectedItem(
                u.isPrincipal() ? "Principal" : "Secundario"
        );

        JCheckBox chkEstado =
                new JCheckBox("Activo", u.isStatus());

        Object[] campos = {
                "Entity ID:", txtEntityId,
                "Person ID:", txtPersonId,
                "Código:", txtCode,
                "Usuario:", txtUsername,
                "Contraseña:", txtPassword,
                "Rol:", cbRol,
                "Estado:", chkEstado
        };

        int op = JOptionPane.showConfirmDialog(
                this,
                campos,
                "Modificar Usuario",
                JOptionPane.OK_CANCEL_OPTION
        );

        if (op == JOptionPane.OK_OPTION) {

            u.setEntityId(Long.valueOf(txtEntityId.getText()));
            u.setPersonId(Long.valueOf(txtPersonId.getText()));
            u.setCode(txtCode.getText());
            u.setUsername(txtUsername.getText());
            u.setPassword(txtPassword.getText());

            u.setPrincipal(
                    cbRol.getSelectedItem().toString().equals("Principal")
            );

            u.setStatus(chkEstado.isSelected());

            if (userDAO.updateUser(u)) {

                JOptionPane.showMessageDialog(this,
                        "Usuario actualizado.");

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(this,
                        "No se pudo actualizar.");
            }
        }
    }

    private void eliminarUsuario() {

        int fila = tabla.getSelectedRow();

        if (fila == -1) {

            JOptionPane.showMessageDialog(this,
                    "Seleccione un usuario.");

            return;
        }

        long id = (long) modelo.getValueAt(fila, 0);

        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Eliminar usuario?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
        );

        if (op == JOptionPane.YES_OPTION) {

            if (userDAO.deleteUser(id)) {

                JOptionPane.showMessageDialog(this,
                        "Usuario eliminado.");

                cargarUsuarios();

            } else {

                JOptionPane.showMessageDialog(this,
                        "No se pudo eliminar.");
            }
        }
    }
}

package dao;

import conexion.ConexionSupabase;
import modelo.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public List<User> listUsers() {

        List<User> list = new ArrayList<>();

        String sql = "SELECT * FROM users ORDER BY id";

        try (
                Connection con = ConexionSupabase.conectar();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                User u = new User();

                u.setId(rs.getLong("id"));
                u.setEntityId((Long) rs.getObject("entity_id"));
                u.setPersonId((Long) rs.getObject("person_id"));
                u.setCode(rs.getString("code"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setPrincipal(rs.getBoolean("is_principal"));
                u.setStatus(rs.getBoolean("status"));

                list.add(u);
            }

        } catch (Exception e) {
            System.out.println("Error listUsers: " + e.getMessage());
        }

        return list;
    }

    public boolean insertUser(User u) {

        String sql = """
                INSERT INTO users
                (entity_id, person_id, code, username, password, is_principal, status)
                VALUES (?,?,?,?,?,?,?)
                """;

        try (
                Connection con = ConexionSupabase.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setObject(1, u.getEntityId());
            ps.setObject(2, u.getPersonId());
            ps.setString(3, u.getCode());
            ps.setString(4, u.getUsername());
            ps.setString(5, u.getPassword());
            ps.setBoolean(6, u.isPrincipal());
            ps.setBoolean(7, u.isStatus());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error insertUser: " + e.getMessage());
            return false;
        }
    }

    public boolean updateUser(User u) {

        String sql = """
                UPDATE users
                SET entity_id=?,
                    person_id=?,
                    code=?,
                    username=?,
                    password=?,
                    is_principal=?,
                    status=?
                WHERE id=?
                """;

        try (
                Connection con = ConexionSupabase.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setObject(1, u.getEntityId());
            ps.setObject(2, u.getPersonId());
            ps.setString(3, u.getCode());
            ps.setString(4, u.getUsername());
            ps.setString(5, u.getPassword());
            ps.setBoolean(6, u.isPrincipal());
            ps.setBoolean(7, u.isStatus());
            ps.setLong(8, u.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error updateUser: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteUser(long id) {

        String sql = "DELETE FROM users WHERE id=?";

        try (
                Connection con = ConexionSupabase.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setLong(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Error deleteUser: " + e.getMessage());
            return false;
        }
    }

    public User findById(long id) {

        String sql = "SELECT * FROM users WHERE id=?";

        try (
                Connection con = ConexionSupabase.conectar();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    User u = new User();

                    u.setId(rs.getLong("id"));
                    u.setEntityId((Long) rs.getObject("entity_id"));
                    u.setPersonId((Long) rs.getObject("person_id"));
                    u.setCode(rs.getString("code"));
                    u.setUsername(rs.getString("username"));
                    u.setPassword(rs.getString("password"));
                    u.setPrincipal(rs.getBoolean("is_principal"));
                    u.setStatus(rs.getBoolean("status"));

                    return u;
                }
            }

        } catch (Exception e) {
            System.out.println("Error findById: " + e.getMessage());
        }

        return null;
    }
}